# Health Protection Console

A Power BI diagnostic console comparing universal health coverage with household out-of-pocket health expenditure.

## Data sources
- World Bank / WHO indicator SH_UHC_SCI
- World Bank / WHO indicator SH.XPD.OOPC.CH.ZS

Common analytical window: 2000–2023. The included prepared CSV contains 4,529 complete country-year observations across 192 countries.

## Open
Open **HealthProtectionConsole.pbip** in Power BI Desktop. If the folder is moved, update the CSV path in Power Query.

## Limitations
Descriptive analysis only. Country averages are unweighted, missing indicator-years are excluded, and association does not establish causality. The protection score is a transparent dashboard construct, not an official indicator.
